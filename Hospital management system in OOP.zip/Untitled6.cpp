// BANK MANAGEMET SYSTEM: MAIN EXECUTABLE FILE

#include<iostream>
#include<iomanip>
#include<cstdlib> // To use rand()
#include<string>
#include"bankmenu.h"

using namespace std;

int main() {

	Main_Menu();

	return 0;
}

